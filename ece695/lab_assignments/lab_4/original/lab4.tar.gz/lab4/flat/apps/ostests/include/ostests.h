#ifndef __FDISK_H__
#define __FDISK_H__

#ifndef NULL
#define NULL (void *)0x0
#endif

#endif
